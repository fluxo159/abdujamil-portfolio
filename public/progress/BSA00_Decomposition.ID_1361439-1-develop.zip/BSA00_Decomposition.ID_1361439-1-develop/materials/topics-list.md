Hello, School21 student! 😉

To help you navigate through the material, we have prepared a list of topics that you will learn in this project.

We will study:
- The IT systems development life cycle;
- Roles in the development team;
- Identification of information sources;
- Compiling a glossary;
- Rules of placement, naming of created artifacts and other rules;
- Decomposition, rules, recommendations for construction.

Now that you know what awaits you in this project, you can slowly begin to study the topics listed above. 😇

We have also prepared a list of recommended software:
- Microsoft Word;
- Microsoft Excel.

Or you can use their analogues, for example, programs from the LibreOffice package or Google Sheets and Google Docs.
