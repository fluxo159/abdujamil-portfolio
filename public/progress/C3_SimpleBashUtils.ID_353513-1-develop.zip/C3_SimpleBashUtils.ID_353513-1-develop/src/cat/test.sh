#!/bin/bash

CAT=./s21_cat
FILE1=../text.txt

echo "Running s21_cat tests..."

# no flags
$CAT $FILE1 > my_cat.txt
cat $FILE1 > orig_cat.txt
diff -s my_cat.txt orig_cat.txt && echo "✅ no-flags"

# -b (number non-blank)
$CAT -b $FILE1 > my_cat.txt
cat -b $FILE1 > orig_cat.txt
diff -s my_cat.txt orig_cat.txt && echo "✅ -b"

# -n (number all lines)
$CAT -n $FILE1 > my_cat.txt
cat -n $FILE1 > orig_cat.txt
diff -s my_cat.txt orig_cat.txt && echo "✅ -n"

# -s (squeeze blank)
$CAT -s $FILE1 > my_cat.txt
cat -s $FILE1 > orig_cat.txt
diff -s my_cat.txt orig_cat.txt && echo "✅ -s"

# -e (show $ at end of line)
$CAT -e $FILE1 > my_cat.txt
cat -e $FILE1 > orig_cat.txt
diff -s my_cat.txt orig_cat.txt && echo "✅ -e"

# -t (show tabs as ^I)
$CAT -t $FILE1 > my_cat.txt
cat -t $FILE1 > orig_cat.txt
diff -s my_cat.txt orig_cat.txt && echo "✅ -t"

rm -f my_cat.txt orig_cat.txt
