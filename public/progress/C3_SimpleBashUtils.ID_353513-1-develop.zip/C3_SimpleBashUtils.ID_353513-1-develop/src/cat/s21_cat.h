#ifndef S21_CAT_H
#define S21_CAT_H

#include <stdbool.h>  // Для типа bool
#include <stdio.h>    // Для стандартного ввода/вывода
#include <stdlib.h>   // Для стандартных функций
#include <string.h>   // Для строковых функций

typedef struct {
  bool b;  // нумеровать непустые строки
  bool e;  // показывать $ в конце строк
  bool n;  // нумеровать все строки
  bool s;  // сжимать пустые строки
  bool t;  // показывать табы как ^I
} cat_flags;

void parse_cat_flags(int argc, char *argv[], cat_flags *flags, int *file_index);
void cat_file(const char *filename, cat_flags flags);

#endif