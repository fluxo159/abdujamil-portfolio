#include "s21_cat.h"  // подключаем файл s21_cat.h

#include "../common/util.h"  // подключаем файл utils.h

// Функция которая определяет что ты написал
void parse_cat_flags(int argc, char *argv[], cat_flags *flags,
                     int *file_index) {
  for (int i = 1; i < argc; i++) {
    if (argv[i][0] == '-') {
      if (strcmp(argv[i], "--number-nonblank") == 0) {
        flags->b = true;
      } else if (strcmp(argv[i], "--number") == 0) {
        flags->n = true;
      } else if (strcmp(argv[i], "--squeeze-blank") == 0) {
        flags->s = true;
      } else if (strcmp(argv[i], "-E") == 0) {
        flags->e = true;
      } else if (strcmp(argv[i], "-T") == 0) {
        flags->t = true;
      } else {
        for (int j = 1; argv[i][j] != '\0'; j++) {
          switch (argv[i][j]) {
            case 'b':
              flags->b = true;
              break;
            case 'e':
              flags->e = true;
              break;
            case 'n':
              flags->n = true;
              break;
            case 's':
              flags->s = true;
              break;
            case 't':
              flags->t = true;
              break;
            case 'E':
              flags->e = true;
              break;
            case 'T':
              flags->t = true;
              break;
          }
        }
      }
    } else {
      *file_index = i;
      break;
    }
  }
}

void cat_file(const char *filename,
              cat_flags flags) {  // просытми словами это функция для открытия
                                  // файла и чтения его и вывод содержимого
  FILE *fp = fopen(filename, "r");  // открываем файл для чтения
  if (!fp) {
    print_error("cannot open file");  // вывводим если ошибка
    return;
  }

  int c, prev = '\n';
  int line_num = 1;
  int empty_count = 0;
  bool squeeze = false;

  while ((c = fgetc(fp)) != EOF) {  // Читает файл посимвольно
    if (flags.s && c == '\n' && prev == '\n') {
      empty_count++;
      if (empty_count > 1) {
        squeeze = true;
        continue;
      }
    } else {
      empty_count = 0;
      squeeze = false;
    }

    if (prev == '\n' && !squeeze) {
      if (flags.b && c != '\n') {
        printf("%6d\t", line_num++);
      } else if (flags.n && !flags.b) {
        printf("%6d\t", line_num++);
      }
    }

    if (flags.t && c == '\t') {
      printf("^I");
    } else if (flags.e && c == '\n') {
      printf("$\n");
    } else {
      putchar(c);
    }
    prev = c;
  }

  fclose(fp);  // Закрывает файл
}

int main(int argc, char *argv[]) {
  if (argc < 2) {  // проверка аргументов
    print_error("usage: s21_cat [OPTION]... [FILE]...");
    return 1;
  }

  cat_flags flags = {false, false, false, false,
                     false};  // Инициализация флагов где все значения по
                              // умолчания false выключены
  int file_index =
      1;  // здесь он смотрит какой флаг пользователь ввел -n -b итд
  parse_cat_flags(argc, argv, &flags, &file_index);

  if (file_index >=
      argc) {  // здесь проверка на наличие файла если его нет то выводит ошибку
    print_error("no input files");
    return 1;
  }

  for (int i = file_index; i < argc;
       i++) {  // цикл ижет по всем файлам который передан аргументом а именно
               // cat_file
    cat_file(argv[i], flags);
  }

  return 0;
}