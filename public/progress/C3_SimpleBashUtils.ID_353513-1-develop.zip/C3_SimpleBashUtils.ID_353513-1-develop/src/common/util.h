#ifndef UTIL_H
#define UTIL_H

#include <stdio.h>

void print_error(const char *msg);

#endif
