#ifndef S21_GREP_H
#define S21_GREP_H

#include <regex.h>  // работа с регулярными выражениями
#include <stdbool.h>  // тип bool (true/false)
#include <stdio.h>    // ввод-вывод
#include <stdlib.h>   // malloc, free и др.
#include <string.h>   // строки (strcmp, strncpy и т.п.)

typedef struct {
  bool i;  // игнорировать регистр (grep -i)
  bool v;  // инвертировать поиск, показывать НЕ совпадающие строки (grep -v)
  bool c;  // посчитать количество совпадений (grep -c)
  bool l;  // показать только имена файлов с совпадениями (grep -l)
  bool n;  // выводить номера строк (grep -n)
  bool h;  // не показывать имя файла при выводе (grep -h)
  bool s;  // подавить ошибки (grep -s)
  bool f;  // читать шаблон из файла (grep -f file)
  bool o;  // выводить только совпавшую часть (grep -o)
  char pattern[256];  // строка-шаблон (например, hello).
} grep_flags;

void parse_grep_flags(int argc, char *argv[], grep_flags *flags,
                      int *file_index);
void grep_file(const char *filename, grep_flags flags, int multiple_files);
void print_match_only(const char *line, regex_t *regex, int line_num,
                      const char *filename, grep_flags flags,
                      int multiple_files);

#endif