#include "s21_grep.h"

#include "../common/util.h"
// эта функция понимает, что хочет пользователь (какой шаблон искать и какие
// опции применить).
void parse_grep_flags(int argc, char *argv[], grep_flags *flags,
                      int *file_index) {
  *file_index = -1;
  flags->pattern[0] = '\0';
  bool pattern_set = false;

  for (int i = 1; i < argc; i++) {
    if (argv[i][0] == '-') {
      if (strcmp(argv[i], "-e") == 0 && i + 1 < argc) {
        strncpy(flags->pattern, argv[++i], sizeof(flags->pattern) - 1);
        pattern_set = true;
      } else {
        for (int j = 1; argv[i][j] != '\0'; j++) {
          switch (argv[i][j]) {
            case 'i':
              flags->i = true;
              break;
            case 'v':
              flags->v = true;
              break;
            case 'c':
              flags->c = true;
              break;
            case 'l':
              flags->l = true;
              break;
            case 'n':
              flags->n = true;
              break;
            case 'h':
              flags->h = true;
              break;
            case 's':
              flags->s = true;
              break;
            case 'f':
              flags->f = true;
              break;
            case 'o':
              flags->o = true;
              break;
          }
        }
      }
    } else if (!pattern_set) {
      strncpy(flags->pattern, argv[i], sizeof(flags->pattern) - 1);
      pattern_set = true;
    } else {
      *file_index = i;
      break;
    }
  }

  if (*file_index == -1) {
    *file_index = argc;
  }
}

void print_match_only(const char *line, regex_t *regex, int line_num,
                      const char *filename, grep_flags flags,
                      int multiple_files) {
  regmatch_t match;
  const char *p = line;

  while (regexec(regex, p, 1, &match, 0) == 0) {
    if (match.rm_so == -1) break;

    // Добавляем имя файла только если multiple_files И не флаг -h
    if (multiple_files && !flags.h) printf("%s:", filename);
    if (flags.n) printf("%d:", line_num);
    printf("%.*s\n", (int)(match.rm_eo - match.rm_so), p + match.rm_so);

    p += match.rm_eo;
  }
}
// Эта функция ищет нужный текст в файле и печатает результат в зависимости от
// флагов.
void grep_file(const char *filename, grep_flags flags, int multiple_files) {
  FILE *fp = fopen(filename, "r");
  if (!fp) {
    if (!flags.s) {
      fprintf(stderr, "grep: %s: No such file or directory\n", filename);
    }
    return;
  }

  regex_t regex;
  int cflags = REG_EXTENDED | (flags.i ? REG_ICASE : 0);
  if (regcomp(&regex, flags.pattern, cflags) != 0) {
    fprintf(stderr, "grep: invalid regex pattern\n");
    fclose(fp);
    return;
  }

  char buffer[4096];
  int line_num = 0, match_count = 0;
  bool file_printed = false;

  while (fgets(buffer, sizeof(buffer), fp)) {
    line_num++;
    int matched = (regexec(&regex, buffer, 0, NULL, 0) == 0);
    if (flags.v) matched = !matched;

    if (matched) {
      match_count++;

      if (flags.l) {
        if (!file_printed) {
          printf("%s\n", filename);
          file_printed = true;
        }
        break;
      }

      if (!flags.c) {
        if (flags.o) {
          print_match_only(buffer, &regex, line_num, filename, flags,
                           multiple_files);
        } else {
          // Добавляем имя файла только если multiple_files И не флаг -h
          if (multiple_files && !flags.h) printf("%s:", filename);
          if (flags.n) printf("%d:", line_num);
          printf("%s", buffer);
          if (buffer[strlen(buffer) - 1] != '\n') printf("\n");
        }
      }
    }
  }

  if (flags.c) {
    // Для флага -c добавляем имя файла только если multiple_files И не флаг -h
    if (multiple_files && !flags.h && !flags.l) printf("%s:", filename);
    if (flags.l && match_count > 0) {
      printf("%s\n", filename);
    } else if (!flags.l) {
      printf("%d\n", match_count);
    }
  }

  regfree(&regex);
  fclose(fp);
}

int main(int argc, char *argv[]) {
  if (argc < 3) {
    fprintf(stderr, "usage: s21_grep [OPTION]... PATTERN [FILE]...\n");
    return 1;
  }

  grep_flags flags = {false, false, false, false, false,
                      false, false, false, false, ""};
  int file_index = 0;
  parse_grep_flags(argc, argv, &flags, &file_index);

  if (strlen(flags.pattern) == 0) {
    fprintf(stderr, "grep: no pattern provided\n");
    return 1;
  }

  int num_files = argc - file_index;

  if (file_index >= argc) {
    grep_file("-", flags, false);
  } else {
    for (int i = file_index; i < argc; i++) {
      grep_file(argv[i], flags, num_files > 1);
    }
  }

  return 0;
}