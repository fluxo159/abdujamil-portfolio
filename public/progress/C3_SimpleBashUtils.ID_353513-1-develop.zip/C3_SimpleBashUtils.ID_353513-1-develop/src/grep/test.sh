#!/bin/bash

GREP=./s21_grep
FILE1=../text.txt
FILE2=../text2.txt  # нужно создать
PATTERN_FILE=patterns.txt  # нужно создать

echo "Запуск полных тестов на Grep"

# Создаем дополнительные файлы для тестов
echo "Hello from second file" > $FILE2
echo "Another line" >> $FILE2
echo "Test pattern" >> $FILE2

echo "Hello" > $PATTERN_FILE
echo "Test" >> $PATTERN_FILE

# 1. Базовый поиск
$GREP Hello $FILE1 > my_grep.txt
grep Hello $FILE1 > orig_grep.txt
diff -s my_grep.txt orig_grep.txt && echo "✅ basic match"

# 2. Игнорирование регистра (-i)
$GREP -i hello $FILE1 > my_grep.txt
grep -i hello $FILE1 > orig_grep.txt
diff -s my_grep.txt orig_grep.txt && echo "✅ -i"

# 3. Инвертирование поиска (-v)
$GREP -v Hello $FILE1 > my_grep.txt
grep -v Hello $FILE1 > orig_grep.txt
diff -s my_grep.txt orig_grep.txt && echo "✅ -v"

# 4. Подсчет совпадений (-c)
$GREP -c Hello $FILE1 > my_grep.txt
grep -c Hello $FILE1 > orig_grep.txt
diff -s my_grep.txt orig_grep.txt && echo "✅ -c"

# 5. Номера строк (-n)
$GREP -n Hello $FILE1 > my_grep.txt
grep -n Hello $FILE1 > orig_grep.txt
diff -s my_grep.txt orig_grep.txt && echo "✅ -n"

# 6. Только имена файлов (-l)
$GREP -l Hello $FILE1 $FILE2 > my_grep.txt
grep -l Hello $FILE1 $FILE2 > orig_grep.txt
diff -s my_grep.txt orig_grep.txt && echo "✅ -l"

# 7. Без имен файлов (-h) - только если несколько файлов
$GREP -h Hello $FILE1 $FILE2 > my_grep.txt
grep -h Hello $FILE1 $FILE2 > orig_grep.txt
diff -s my_grep.txt orig_grep.txt && echo "✅ -h"

# 8. Подавление ошибок (-s)
$GREP -s Hello nofile.txt > my_grep.txt 2>/dev/null
grep -s Hello nofile.txt > orig_grep.txt 2>/dev/null
diff -s my_grep.txt orig_grep.txt && echo "✅ -s"

# 9. Шаблоны из файла (-f)
$GREP -f $PATTERN_FILE $FILE1 > my_grep.txt
grep -f $PATTERN_FILE $FILE1 > orig_grep.txt
diff -s my_grep.txt orig_grep.txt && echo "✅ -f"

# 10. Только совпадения (-o)
$GREP -o Hello $FILE1 > my_grep.txt
grep -o Hello $FILE1 > orig_grep.txt
diff -s my_grep.txt orig_grep.txt && echo "✅ -o"

# 11. Комбинации флагов (-iv)
$GREP -iv hello $FILE1 > my_grep.txt
grep -iv hello $FILE1 > orig_grep.txt
diff -s my_grep.txt orig_grep.txt && echo "✅ -iv"

# 12. Комбинации флагов (-in)
$GREP -in hello $FILE1 > my_grep.txt
grep -in hello $FILE1 > orig_grep.txt
diff -s my_grep.txt orig_grep.txt && echo "✅ -in"

# 13. Комбинации флагов (-vn)
$GREP -vn Hello $FILE1 > my_grep.txt
grep -vn Hello $FILE1 > orig_grep.txt
diff -s my_grep.txt orig_grep.txt && echo "✅ -vn"

# Очистка
rm -f my_grep.txt orig_grep.txt $FILE2 $PATTERN_FILE

echo "Все тесты завершены"