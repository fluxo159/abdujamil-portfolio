# Task 1 - Тест-кейсы для сайта https://www.saucedemo.com/

## Тест-кейс 1. Позитивная проверка авторизации


**ID:** TC-001  
**Заголовок:** Авторизация с валидным логином и паролем  
**Предусловия:** Пользователь открыл сайт [https://www.saucedemo.com/](https://www.saucedemo.com/).  
**Шаги:**
1. В поле "Accepted usernames are:" есть Username
1.5 Пользователь может взять любой из Username Пример "standard_user" или "error_user"
2. В поле "Password for all users:" есть Password
2.5 Пользователь может взять из "Password for all users:" пороль "secret_sauce"
3. Нажать кнопку **Login**.  
**Ожидаемый результат:** Пользователь успешно авторизован и перенаправлен на страницу с товарами ("Products").  
**Результаты:** Результаты разные при указании разных "Username" Пример если использовать "standard_user" пороль "secret_sauce" то тавары будут "Sauce Labs Backpack", "Sauce Labs Bolt T-Shirt", "Sauce Labs Onesie", "Sauce Labs Bike Light", "Sauce Labs Fleece Jacket", "Test.allTheThings() T-Shirt (Red)".
А при использовании Username "locked_out_user" сайт блокирует вывводя ошибку "Epic sadface: Sorry, this user has been locked out."
А при использовании Username "problem_user" сайт блокирует вывводя ошибку вывводя только один вид товара "Sauce Labs Backpack" при перерходе по товару Sauce Labs Backpack выводит другой товар "Sauce Labs Fleece Jacket"
---

## Тест-кейс 2. Негативная проверка (невалидный пароль)

**ID:** TC-002  
**Заголовок:** Ошибка при авторизации с неверным паролем  
**Предусловия:** Пользователь открыл сайт [https://www.saucedemo.com/](https://www.saucedemo.com/).  
**Шаги:**
1. Ввести в поле "Username" значение `standard_user`.  
2. Ввести в поле "Password" значение `wrong_password`.  
3. Нажать кнопку **Login**.  
**Ожидаемый результат:** Отображается сообщение об ошибке:  
`Epic sadface: Username and password do not match any user in this service`.  
Пользователь остаётся на странице логина.  
**Постусловия:** Нет.

---

## Тест-кейс 3. Негативная проверка (пустые поля)

**ID:** TC-003  
**Заголовок:** Ошибка при попытке авторизации с пустыми полями логина и пароля  
**Предусловия:** Пользователь открыл сайт [https://www.saucedemo.com/](https://www.saucedemo.com/).  
**Шаги:**
1. Оставить поля "Username" и "Password" пустыми.  
2. Нажать кнопку **Login**.  
**Ожидаемый результат:** Отображается сообщение об ошибке:  
`Epic sadface: Username is required`.  
**Постусловия:** Нет.