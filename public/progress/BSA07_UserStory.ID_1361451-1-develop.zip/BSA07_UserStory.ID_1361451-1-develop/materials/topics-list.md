Hello, School21 student! 😉

To help you navigate through the material, we have prepared a list of topics that you will learn in this project.

We will learn:
- User Story;
- Structure of US;
- Acceptance criteria;
- Test scenarios;
- Benefits and limitations of US;
- Recommendations for using US.

Now that you know what to expect in this project, you can slowly start studying the topics listed above. 😇

We have also prepared a list of recommended software:
- Microsoft Office (Microsoft Word).

Or you can use its analog, for example, LibreOffice Writer and Google Docs.
