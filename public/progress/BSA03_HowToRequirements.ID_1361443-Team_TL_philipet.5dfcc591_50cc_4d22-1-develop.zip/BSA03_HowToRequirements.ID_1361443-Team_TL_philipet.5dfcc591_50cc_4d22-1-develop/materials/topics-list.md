Hello, School21 student! 😉

To help you navigate through the material, we have prepared a list of topics that you will learn in this project.

We will study:
- Ways to identify requirements;
- Description of business requirements;
- Roles in the project and their functions.

Now that you know what to expect in this project, you can slowly begin to study the topics listed above. 😇

We have also prepared a list of recommended software:
- Microsoft Office (Microsoft Word).

Or you can use an analog, for example, a program from the LibreOffice package or Google Docs.
