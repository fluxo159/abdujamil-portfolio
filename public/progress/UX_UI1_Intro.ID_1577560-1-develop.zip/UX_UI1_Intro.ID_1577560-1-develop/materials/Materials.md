1. UX и UI-дизайн: что это, в чем разница (Practicum.Yandex)
Русский
https://practicum.yandex.ru/blog/chto-takoe-ux-ui-dizayn

2. Обзор профессии
Русский
https://skillbox.ru/media/design/ux_ui_dizayn_chto_eto_takoe/?utm_source=chatgpt.com

3. 5 различий между UI и UX дизайном (UXGU.ru)
Русский
https://uxgu.ru/ux-vs-ui/

4. UI vs UX Design: What's the Difference? (CareerFoundry)
Английский
https://careerfoundry.com/en/blog/ux-design/the-difference-between-ux-and-ui-design-a-laymans-guide

5. Чем отличается UX- от UI-дизайна? (Purrweb)
Русский
https://www.purrweb.com/ru/blog/ui-ux-v-chem-raznica

6. Human-Centered Design
Русский
https://bangbangeducation.ru/point/ux-ui-dizain/chto-takoe-hcd/

7. Стандарты HCD и ISO
Русский
https://habr.com/ru/articles/258635/

8. UX Research Cheat Sheet — NN/g
Английский
https://www.nngroup.com/articles/ux-research-cheat-sheet

9. UX-исследования: когда нужны, как проводить, методы … (BangBang Education)
Русский
https://bangbangeducation.ru/point/ux-ui-dizain/ux-issledovaniya/?utm_source=chatgpt.com

10. DIY. Гайд по методам продуктовых исследований — Sense23
Русский
https://sense23.com/post/diy-gajd-po-metodam-produktovyh-issledovanij-kachestvennye-kolichestvennye-ux-issledovaniya?utm_source=chatgpt.com





