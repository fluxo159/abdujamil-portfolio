Hello, School21 student! 😉

To help you navigate through the material, we have prepared a list of topics that you will learn in this project.

We will study:
- Requirements;
- Types of requirements;
- Levels of requirements;
- As Is & To Be;
- Context Diagram.

Now that you know what to expect in this project, you can slowly begin to study the topics listed above. 😇

We have also prepared a list of recommended software:
- Microsoft Word;
- Microsoft Excel;
- Microsoft Visio.

Or you can use their analogues, for example, programs from the LibreOffice package or Google Sheets and Google Docs.

And there are programs similar to Visio for drawing diagrams: diagrams.net and LibreOffice Draw.