Hello, School21 student! 😉

To help you navigate through the material, we have prepared a list of topics that you will learn in this project.

We will study:
- Stakeholders;
- Roles;
- List of stakeholders;
- Onion Diagram.

Now that you know what to expect in this project, you can slowly begin to study the topics listed above. 😇

We have also prepared a list of recommended software:
- Microsoft Visio;
- Microsoft Excel.

Or you can use their analogues, for example, programs from the LibreOffice package. 

And there are programs similar to Visio for drawing diagrams: diagrams.net and LibreOffice Draw.