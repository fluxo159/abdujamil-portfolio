1. [Принципы построения логики экранов](https://ux.pub/alexeygordeev/kak-prostranstviennaia-loghika-mozhiet-sdielat-dizain-vashiegho-produkta-bolieie-intuitivnym-i-profiessionalnym-2g8g).

2. [Психологические законы UX](https://skillbox.ru/media/design/psyc-ux-1/).
   
3. [Базовые продуктовые метрики](https://blog.uxfeedback.ru/tag/feedback/).