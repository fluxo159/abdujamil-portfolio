Hello, School21 student! 😉

To help you navigate through the material, we have prepared a list of topics that you will learn in this project.

We will study:
- Object Domain;
- Entities;
- CRUD;
- Data Dictionary;
- ERD.

Now that you know what awaits you in this project, you can slowly begin to study the topics listed above. 😇

We have also prepared a list of recommended software:
- Microsoft Visio;
- Microsoft Excel.

Or you can use their analogues, for example, LibreOffice Calc or Google Sheets. 

And there are programs similar to Visio for drawing diagrams: diagrams.net and LibreOffice Draw.